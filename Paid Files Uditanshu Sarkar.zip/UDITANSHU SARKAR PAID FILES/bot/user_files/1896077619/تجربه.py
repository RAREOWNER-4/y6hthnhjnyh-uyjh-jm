import telebot

API_TOKEN = '7051657580:AAF_ItePcINacJuS0ZNiK2kbV4b1Qc59V44' #توكنك بدال الاصفار

bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_name = message.from_user.first_name
    bot.reply_to(message, f"الاستضافة تعمل {user_name}! ")

bot.polling()