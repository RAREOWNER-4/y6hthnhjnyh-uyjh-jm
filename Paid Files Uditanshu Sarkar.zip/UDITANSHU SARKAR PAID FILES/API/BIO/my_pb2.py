# source: my.proto
"""Generated protocol buffer code."""
from google.protobuf.internal import builder as _builder
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
# @@protoc_insertion_point(imports)

_sym_db = _symbol_database.Default()




DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x08my.proto\"}\n\tSignature\x12\x0e\n\x06\x66ield2\x18\x02 \x01(\x03\x12\x0e\n\x06\x66ield5\x18\x05 \x01(\x03\x12\x0e\n\x06\x66ield6\x18\x06 \x01(\x03\x12\x0e\n\x06\x66ield8\x18\x08 \x01(\t\x12\x0e\n\x06\x66ield9\x18\t \x01(\x03\x12\x0f\n\x07\x66ield11\x18\x0b \x01(\x03\x12\x0f\n\x07\x66ield12\x18\x0c \x01(\x03\x62\x06proto3')

_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, globals())
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'my_pb2', globals())
if _descriptor._USE_C_DESCRIPTORS == False:

  DESCRIPTOR._options = None
  _SIGNATURE._serialized_start=12
  _SIGNATURE._serialized_end=137
# @@protoc_insertion_point(module_scope)
