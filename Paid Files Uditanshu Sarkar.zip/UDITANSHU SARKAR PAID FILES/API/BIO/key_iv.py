# key_iv.py
AES_KEY = b'Yg&tc%DEuh6%Zc^8'  # 16-byte AES key
AES_IV = b'6oyZDr22E3ychjM%'   # 16-byte IV